var React = require('react');
var ReactDom = require('react-dom');
var Main = require('./components/Main');

ReactDom.render(
  <Main/>,
  document.getElementById('app')
);
